# CapAnalysis
PCAP from another point of view.

# About
CapAnalysis performs indexing of data set of PCAP files and presents their contents in many forms, starting from a list of TCP, UDP or ESP streams/flows, passing to the geo-graphical representation of the connections.

# License
CapAnalysis is released under GPLv2.
