--- clean all tables except users and groups

drop database capanalysis;
drop user capana;
