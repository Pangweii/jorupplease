-- Copyright (c) 2012 Gianluca Costa
--
-- Author: Gianluca Costa, 2012
--      g.costa@capanalysis.net
--

CREATE USER capana WITH PASSWORD '123456' CREATEDB;
ALTER USER capana WITH PASSWORD '123456';

