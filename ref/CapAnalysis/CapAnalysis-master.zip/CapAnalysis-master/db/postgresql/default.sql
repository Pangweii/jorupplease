INSERT INTO groups VALUES (1, 'admin');
INSERT INTO groups VALUES (2, 'users');
INSERT INTO classifications VALUES (1, 0, 'Normal', '#ffffff', '#dddddd');
INSERT INTO users VALUES (1, 'admin', '4295173f5047ed4edf9eee2a047abc33', 'demo1@xplico.org', TRUE, 'none', 'Xplico', 'Team', '1999-01-01 00:00:00', 0, 'FULL', TRUE, TRUE, 1, 0);
INSERT INTO users VALUES (2, 'xplico', '4295173f5047ed4edf9eee2a047abc33', 'demo2@xplico.org', TRUE, 'none', 'Xplico', 'Team', '1999-01-01 00:00:00', 0, 'NORMAL', TRUE, TRUE, 2, 0);
INSERT INTO versions (ver) VALUES ('1.1');
