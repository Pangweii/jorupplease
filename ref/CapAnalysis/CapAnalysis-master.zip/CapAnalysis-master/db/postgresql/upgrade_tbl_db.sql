-- Copyright (c) 2012-2013 Gianluca Costa
--
-- Author: Gianluca Costa, 2012-2016
--      g.costa@capanalysis.net
--

\c capanalysis
\i versions.sql






