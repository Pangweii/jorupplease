/* config.h
 *
 * $Id: $
 *
 * CapAnalysis
 * By Gianluca Costa <g.costa@xplico.org>
 * Copyright 2012-2016 Gianluca Costa. Web: www.capanalysis.net
 *
 */


#ifndef __CONFIG_H__
#define __CONFIG_H__

#define POSTGRESQL_USER  "postgres"  // the Linux username: For Ubuntu and Debian -> postgres


#endif /* __CONFIG_H__ */
