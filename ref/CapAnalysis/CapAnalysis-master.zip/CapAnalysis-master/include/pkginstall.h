#ifndef __PKGINSTALL_H__
#define __PKGINSTALL_H__


int PkgInstall(char *install_path, char *chown_sd);


#endif
