<?php
class HelloShell extends AppShell {
    public function main() {
        $this->out('Hello world.');
    }
}
