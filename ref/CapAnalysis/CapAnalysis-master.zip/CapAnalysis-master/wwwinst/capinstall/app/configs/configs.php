<?php
// debug
$enable_dbg = 0;

// file delle configurazioni
$sessiondir = '/tmp/'; // dir per la gestine delle session 
$es_session = 'capana'; // nome della sessione

// dir dell'app
$tmpdir = '../../'; // dir temporanea
$workdir = '/tmp/'; // dir di lavoro, dove sono depositati i file in RW
$bckdir = '/tmp/';  // dir di backup

// DB

// default controller
$default_controller = 'default';

// file d'appoggio dell'app
$ROOT_DIR='/opt/capanalysis/';
