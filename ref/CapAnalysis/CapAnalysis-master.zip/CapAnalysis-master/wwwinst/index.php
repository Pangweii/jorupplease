<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Pragma" content="no-cache" />
<meta http-equiv="Expires" content="-1" />
<meta http-equiv="Cache-Control" content="no-cache" />
</head>
<body>
<script>
window.location.href = "./capinstall";
</script>
</body>
</html>
