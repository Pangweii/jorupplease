<?php
include 'db_login.php';
$conn = mysqli_connect($host, $id, $pw, $dbname);
if (mysqli_connect_errno()) {
    die('Connect Error: '.mysqli_connect_error());
}
?>
<html>
  <head>
   <style>
    div{
      margin:0;
      padding:0;
     
    }
   </style>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript" src="https://www.google.com/jsapi"></script>
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script type="text/javascript">
  
      google.charts.load('current', {'packages':['geochart']});
      google.charts.setOnLoadCallback(drawRegionsMap);

 
      function drawRegionsMap() {
         var mydiv = document.getElementById("regions_div");
         var curr_width = mydiv.clientWidth;
         var curr_height= mydiv.clientHeight;
     

         var data= google.visualization.arrayToDataTable([
            <?php
                echo '["countries","traffic"],';

                $userid = $_COOKIE['userid'];
                          
                try{    
                  $query = "SELECT countries, traffic FROM geomap WHERE id='$userid'";    
                  
                  $result = $conn->query($query);
          
                  while( $row = mysqli_fetch_array($result)){
                 
                      echo '["'.$row["countries"].'",'.$row["traffic"].'],';
               
                  }

                  mysql_close($conn);
                

                }catch(PDOException $e){
                  $message = '<script>alert($e->getMessage())</script>';
                }
            ?>
          ],false);
      

        var options = {
          colors: ['#DCDCDC'],
          tooltip: { isHtml: true,  textStyle: { fontSize: 11  } },
          colorAxis: { colors: ['#429F6B'] }, //#4DB8FF
          width:['curr_width'],
          height:['curr_height'],
          backgroundColor:'#eee'
        };

        var chart = new google.visualization.GeoChart(document.getElementById('regions_div'));

            chart.draw(data, options);
      }




    </script>
  </head>
  <body>

    <div id="regions_div" onClick="myClickHandler()" style="margin:10px auto; width:800; height:auto;"></div>
  </body>
</html>