<?php

$host = "localhost";
$id = "root";
$pw = "tnwlsdlzhrmah!!";
$dbname = "forensics";


 ?>
