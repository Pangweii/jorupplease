<?php
include 'db_login.php';
//이전에 이용했던 쿠키가 있는지 확인
if(isset($_COOKIE['userid'])){
    
    // 데이터베이스 연결
    $conn = mysqli_connect($host, $id, $pw, $dbname);
        if (mysqli_connect_errno()) {
            die('Connect Error: '.mysqli_connect_error());
        }

    $tablename = array("flow", "geomap", "protocol", "IO", "timeline");
    $userid = $_COOKIE['userid'];
    
    //각 유저가 사용했던 DB테이블 정리
    for($i=0; $i<=4; $i++){
      $cls_qry = "DELETE FROM $tablename[$i] WHERE id='$userid'";
      mysqli_query($conn, $cls_qry);
    }

    //복원 파일 경로 쿠키 해제
    setcookie("filepath", "", time() - 3600);
    setcookie("userid", "", time() - 3600);
}
mysqli_close($conn);
?>

<!DOCTYPE html> 
<html> 
<head>


<link rel="shortcut icon" href="image/Favicon.gif"> 
  <title>Packet Analysis & Restore For Network Forensics</title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8"> 
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="">
  <meta name="author" content="">
  <!-- 합쳐지고 최소화된 최신 CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">

  <!-- 부가적인 테마 -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap-theme.min.css">

  <!-- 합쳐지고 최소화된 최신 자바스크립트 -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js"></script>
<style type="text/css">
.fsSubmitButton
{
padding: 6px 15px 6px !important;
font-size: 14px !important;
background-color: #6ED746;
font-weight: bold;
text-shadow: 1px 1px #57D6C7;
color: #ffffff;
border-radius: 5px;
-moz-border-radius: 5px;
-webkit-border-radius: 5px;
border: 1px solid #6ED746;
cursor: pointer;
box-shadow: 0 1px 0 rgba(255, 255, 255, 0.5) inset;
-moz-box-shadow: 0 1px 0 rgba(255, 255, 255, 0.5) inset;
-webkit-box-shadow: 0 1px 0 rgba(255, 255, 255, 0.5) inset;
}
section#upload{
  margin-top:50px;
  
  width:400px;

}
ul{
  padding:0;
  margin-top:10px;
}
li{
  padding:0;
  list-style-type: none;
  border:3px solid;
  border-radius:3px;
  border-color:#9ACD32;
  color:#006400;
  width:350px;
  height:auto;
  text-align:left;
}

</style>

</head>

<body> 

<div class="container" style="margin:0 auto;">
 
    <center>
    <section id="image" style="margin-top:100px;">
      <img src="image/1048_1.jpg"> <!--첫 화면 이미지 출력-->


    </section>
    </center>

    <section id="upload" style="margin:0 auto; padding-top:30px; padding-left:37px;">
<!--파일 전송 폼 시작-->
    <form action="upload_check.php" method="POST" enctype="multipart/form-data">

        <input id ="mac" name="mac" type="text" size="47" placeholder="MAC주소를 입력하면 정확한 값을 알 수 있습니다.">
        
        <input id="input-1a" type="file" size="35" name="input-1a" class="file">
      

        <ul id="file-list" type="hidden"> 
        
          <li class="no-items">업로드되지 않았습니다.</li> 
        </ul>



      <script>
        var filesUpload = document.getElementById("input-1a"),
            fileList = document.getElementById("file-list");
        
        function traverseFiles (files) {
          var li,
              file,
              fileInfo;
          fileList.innerHTML = "";
            
          for (var i=0, il=files.length; i<il; i++) {
            li = document.createElement("li");
            file = files[i];

            /*파일 사이즈 MB 소숫점 2째자리까지 계산*/
            dumpsize=(file.size/1024)/1024;
            dumpsize=(Math.round(dumpsize*100))/100; 

            fileInfo = "<div><strong>파일이름:</strong> "

                         + file.name + "</div>";
            fileInfo += "<div><strong>파일크기:</strong> "
                        
                          + dumpsize + " MB</div>";
            
            li.innerHTML = fileInfo;
            fileList.appendChild(li);
          };
        };
        
        filesUpload.onchange = function () {
          traverseFiles(this.files);
        };
      </script>
    <center><input type="submit" value="업로드" name="submit" class="fsSubmitButton"></center>
    </form>
   
    </section>


    <hr>
<!--화면 밑 카피라이트-->
  <footer>
    <p>&copy; 상부상조 2016</p>
  </footer>
</div>


</body> 


</html>