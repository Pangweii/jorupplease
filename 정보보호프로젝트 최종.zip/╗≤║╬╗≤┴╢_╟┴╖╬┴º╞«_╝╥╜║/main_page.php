
<!DOCTYPE html>
<html lang="ko">

<head>
<link rel="shortcut icon" href="image/Favicon.gif"> 
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<!-- 합쳐지고 최소화된 최신 CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">

	<!-- 부가적인 테마 -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap-theme.min.css">

	<!-- 합쳐지고 최소화된 최신 자바스크립트 -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js"></script>
	<style type="text/css">
		* { font-family: NanumGothic, 'Malgun Gothic'; }
		body {
		  padding-top: 50px;
		  padding-bottom: 20px;
		}
  
	</style>

	<title> Packet Analysis & Restore For Network Forensics</title>

</head>

<body>
<div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
  <div class="container">
    <div class="navbar-header">
   
      <a class="navbar-brand" href="#">Project by 相扶相助 </a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a href="./main_page.php">홈</a></li>
        <li><a href="./sub_page_1.php">상세정보</a></li>
        <li><a href="./sub_page_2.html">복원</a></li>
      </ul>
     <ul class="nav navbar-nav navbar-right">
        <li><a href="./index.php" alt="재업로드"><span class="glyphicon glyphicon-transfer" ></span></a></li>

        </ul>
      </div>
     
  </div>
</div>
 
<div class="jumbotron">
  <div class="container" style="height:470px;">
  	<iframe src="Geomap3.php" 
  	width="100%" height="100%" frameborder="no" resize scrolling="no" marginheight="0" marginwidth="0"></iframe>
  </div>
</div>
 
<div class="container">
  <div class="row">
    <div class="col-md-4" style="margin-right:30%; height:470px;">
      <h2>I/O 통계 차트</h2>
           <iframe src="pie_chart2.php" 
       frameborder="no" resize scrolling="no" marginheight="0" marginwidth="0" style="height:400px;width:600px; margin-bottom:0px; padding-bottom: 0px;"></iframe>
      <!--<p><a class="btn btn-default" href="#" role="button">더보기 &raquo;</a></p>-->
    </div>

    <div class="col-md-4">
      <h2>프로토콜 TOP5</h2>
       <iframe src="protocol_chart2.php" 
       frameborder="no" resize scrolling="no" marginheight="0" marginwidth="0" style="height:400px;width:400px; margin-bottom:0px; padding-bottom: 0px;"></iframe>
      <!--<p><a class="btn btn-default" href="#" role="button">더보기 &raquo;</a></p>-->
    </div>
  </div>
</div>

<div class="jumbotron">
  <div class="container" style="height:230px;">
    <iframe src="timeline.php" 
    width="100%" height="300" frameborder="no" resize scrolling="no" marginheight="0" marginwidth="0"></iframe>
  </div>
</div>
  

<div class="container">  
  <footer>
   <p>&copy; 상부상조 2016</p>
  </footer>
</div>
 
</body>
</html>


</body>

</html>
