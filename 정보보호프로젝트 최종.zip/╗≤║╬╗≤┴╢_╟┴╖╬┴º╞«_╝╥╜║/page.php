<?php
header("Content-type: text/html; charset=utf-8");
 
function page_nav($total_page,$current_page,$url){
 
  //page_block 1개의 블럭에 몇개의 페이지 설정 [prev] 1|2|3|4|5...[next]
    if(!$page_block) { $page_block = 10; }
 
    //페이징 네비게이션의 시작페이지 및 마지막페이지 구하기
    $start_page = intval(($current_page - 1) / $page_block) * $page_block + 1;
  $end_page = $start_page + $page_block - 1;
 
  //마지막페이지 값보다 전체페이지가 작다면 마지막페이지 값은 전체페이지 값으로 변경
  if ($total_page <= $end_page) { $end_page = $total_page; }
 
  //현재페이지가 페이지블럭보다 크다면 [prev]에 링크기능 사용
  if ( $current_page > $page_block) {
  $c_page = intval($start_page - 1);
     $url_page = "<a href='$url"."page=$c_page'>";
      echo ("$url_page");
    echo("[prev]</a> .. ");
    }
  else{
    echo("[prev]</a>  ");
  }
 
  for ($c_page=$start_page; $c_page <= $end_page; $c_page++) {
    if ($c_page == $current_page) {
        echo "<b>$current_page</b>";
      } else {
        $url_page = "<a href='$url"."page=$c_page'>";
        echo ("$url_page");
      echo("[$c_page]</a>");
      }
  }
 
  //마지막 페이지 보다 전체 페이지가 크다면 [next]에 링크기능 사용
    if ( $total_page > $end_page) {
      $c_page = intval($end_page + 1);  
      $url_page = " .. <a href='$url"."page=$c_page'>";
      echo ("$url_page");
    echo("[next]</a>");
    }
  else{
    echo("  [next]");
  }
}