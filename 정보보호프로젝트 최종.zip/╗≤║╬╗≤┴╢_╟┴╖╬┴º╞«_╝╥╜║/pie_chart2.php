<?php
include 'db_login.php';
$conn = mysqli_connect($host, $id, $pw, $dbname);
if (mysqli_connect_errno()) {
    die('Connect Error: '.mysqli_connect_error());
}

?>
<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
     <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {


       var data = new google.visualization.arrayToDataTable([
         <?php
                echo '["In/OUT","Traffic"],';

                $userid = $_COOKIE['userid'];
                          
                try{    
                  $query = "SELECT input, output FROM IO WHERE id='$userid'";    
                  
                  $result = $conn->query($query);
          
                  while( $row = mysqli_fetch_array($result)){
                 
                      echo '["Input",'.$row["input"].'],["Output",'.$row["output"].']';
               
                  }
                

                }catch(PDOException $e){
                  $message = '<script>alert($e->getMessage())</script>';
                }
            ?>
          ]);
       
        


        var options = {
          pieHole: 0.5,
          pieSliceTextStyle: {
            color: 'black',
          },
          legend: 'right',
          chartArea:{ left:10, top:20,},
          colors: ["#429F6B","#DCDCDC"]

        };

        //JSON 데이터를 불러옴

        //차트에 옵션을 추가하여 드로우
        var chart = new google.visualization.PieChart(document.getElementById('donut_single'));
        chart.draw(data, options);
      }
    </script>
  </head>
  <body>
    <div id="donut_single" style="width: 900px; height: 500px; margin-left: 0px; padding-left: 0px;"></div>


  </body>
</html>