"""
Don't Forget List
자기 자신과의 통신(src==dest)일 경우 I/O 모두 count된다.
현재 사용하는 sort 방식은 딕셔너리를 리스트로 강제변환 시킨다.
Ethernet padding 계산해서 떼버리기

"""

##파이썬 기본 제공 라이브러리
import sys
import datetime, time
import operator
import os
import urllib.request
import json
import uuid

##컴파일 모드설정(로컬 1, 서버 2)
compile_mode=2

if compile_mode==1:
	sys.path.append("C:/Users/jinyoung/Documents/GitHub/TEMP/jp/pymodule")
elif compile_mode==2:
	sys.path.append("/var/www/html/proc/pymodule")

##유저 라이브러리
import function
import dictionary


##패킷의 경로설정
if compile_mode==1:
	fpath = "C:/Users/jinyoung/Documents/GitHub/TEMP/test_pcap/파일유출4.pcap"
	flag_add=input("Host MAC주소를 입력하세요 : ")
	t1 = time.time() # start time
	
	##Host MAC 주소 입력 체크
	if flag_add!="":
		flag_add=flag_add.upper()
	else:
		flag_add=""
elif compile_mode==2:
	fpath=sys.argv[1]    #DumpFile path
	try:
		flag_add=sys.argv[2] #I/O 호스트 맥주소
		flag_add=flag_add.upper()
	except:
		flag_add=""


#파일 바이너리 오픈
byteBuffer=function.readfile(fpath)

#업로드 파일 체크
cap_chk=function.chk_file(byteBuffer)
if cap_chk == 0:
	sys.stdout.write(-1)
	sys.exit()

#offset 세팅 및 global header 파싱
_offset=0;
_offset=function.parse_ghdr(1, byteBuffer)

# 랜덤문자열로 프론트에 전송할 아이디 값 생성
userid=str(uuid.uuid4()).replace("-", "")

##2계층 프로토콜 확인
# ethernet일 경우
if dictionary.pcap_hdr_s['network']==[0x01, 0x00, 0x00, 0x00]:
	flow_qry=""
	#패킷 분석 루프
	frame_num=0
	while function.next_pkt_chk(_offset, byteBuffer):
		####################분할된 패킷 파싱####################
		##Record Header 파싱
		_offset=function.parse_rhdr(_offset, byteBuffer)

		##Record Data 파싱
		#* 패킷렝스 계산하는 것 밑에 있으니까 이부분 빼고 함수구조 바꿀것
		pkt_length=function.get_pktdata_length(dictionary.pcap_hdr_s['snaplen'], dictionary.pkt_hdr_s['incl_len'], dictionary.pkt_hdr_s['orig_len'])
		rdata=function.read_rdata(_offset, byteBuffer, function.hex_to_dec(pkt_length))
		_offset=_offset+function.hex_to_dec(pkt_length)

		# Ethernet Frame 파싱
		rdata_offset=0
		function.parse_ethernet(rdata, rdata_offset)
		

		####################파싱된 데이터에서 필요한 데이터 세팅####################
		# frame_num증가
		frame_num+=1

		# 현재 패킷의 길이정보
		pkt_length=function.get_pktdata_length(dictionary.pcap_hdr_s['snaplen'], dictionary.pkt_hdr_s['incl_len'], dictionary.pkt_hdr_s['orig_len'])

		# 현재 패킷의 프로토콜 레이어 수
		layerCnt=len(dictionary.protocol_list)+1

		# 패킷 캡쳐 시간값
		time_sec=dictionary.pkt_hdr_s['ts_sec']
		
		# IPv4 패킷의 출발지 목적지 주소의 숫자 값
		orgin_src=""
		orgin_dst=""

		# I/O 카운트를 위한 이더넷 맥주소 세팅
		src_mac=str("%02X" % dictionary.eth_frame['src_mac'][0])+":"+str("%02X" % dictionary.eth_frame['src_mac'][1])+":"+str("%02X" % dictionary.eth_frame['src_mac'][2])+":"+str("%02X" % dictionary.eth_frame['src_mac'][3])+":"+str("%02X" % dictionary.eth_frame['src_mac'][4])+":"+str("%02X" % dictionary.eth_frame['src_mac'][5])
		dst_mac=str("%02X" % dictionary.eth_frame['des_mac'][0])+":"+str("%02X" % dictionary.eth_frame['des_mac'][1])+":"+str("%02X" % dictionary.eth_frame['des_mac'][2])+":"+str("%02X" % dictionary.eth_frame['des_mac'][3])+":"+str("%02X" % dictionary.eth_frame['des_mac'][4])+":"+str("%02X" % dictionary.eth_frame['des_mac'][5])
		src_mac=src_mac.replace("0x","")
		dst_mac=dst_mac.replace("0x","")

		# 패킷의 3계층 프로토콜 정보 확인 후 출발지, 목적지 주소 세팅
		if layerCnt>=3 and dictionary.protocol_list[1]=="ARP":
			src_add=str("%02X" % dictionary.arp_pkt['sender_mac'][0])+":"+str("%02X" % dictionary.arp_pkt['sender_mac'][1])+":"+str("%02X" % dictionary.arp_pkt['sender_mac'][2])+":"+str("%02X" % dictionary.arp_pkt['sender_mac'][3])+":"+str("%02X" % dictionary.arp_pkt['sender_mac'][4])+":"+str("%02X" % dictionary.arp_pkt['sender_mac'][5])
			dst_add=str("%02X" % dictionary.arp_pkt['target_mac'][0])+":"+str("%02X" % dictionary.arp_pkt['target_mac'][1])+":"+str("%02X" % dictionary.arp_pkt['target_mac'][2])+":"+str("%02X" % dictionary.arp_pkt['target_mac'][3])+":"+str("%02X" % dictionary.arp_pkt['target_mac'][4])+":"+str("%02X" % dictionary.arp_pkt['target_mac'][5])
			src_add=src_add.replace("0x","")
			dst_add=dst_add.replace("0x","")
		elif layerCnt>=3 and dictionary.protocol_list[1]=="IPv4":
			orgin_src=dictionary.ipv4_pkt['ip_src']
			orgin_dst=dictionary.ipv4_pkt['ip_dst']

			src_add=str(dictionary.ipv4_pkt['ip_src'][0])+"."+str(dictionary.ipv4_pkt['ip_src'][1])+"."+str(dictionary.ipv4_pkt['ip_src'][2])+"."+str(dictionary.ipv4_pkt['ip_src'][3])
			dst_add=str(dictionary.ipv4_pkt['ip_dst'][0])+"."+str(dictionary.ipv4_pkt['ip_dst'][1])+"."+str(dictionary.ipv4_pkt['ip_dst'][2])+"."+str(dictionary.ipv4_pkt['ip_dst'][3])
		elif layerCnt>=3 and dictionary.protocol_list[1]=="IPv6":
			src_add=""
			dst_add=""
			for i in range(0, 16, 2):
				src_add+=str("%02X" % dictionary.ipv6_pkt['src_add'][i])
				dst_add+=str("%02X" % dictionary.ipv6_pkt['dest_add'][i])
				src_add+=str("%02X" % dictionary.ipv6_pkt['src_add'][i+1])+":"
				dst_add+=str("%02X" % dictionary.ipv6_pkt['dest_add'][i+1])+":"

			src_add=src_add.rstrip(":")
			dst_add=dst_add.rstrip(":")
			src_add=src_add.replace("0x","")
			dst_add=dst_add.replace("0x","")
		elif layerCnt==2:
			src_add=src_mac
			dst_add=dst_mac
		else:
			src_add=""
			dst_add=""

		# 패킷의 4계층 프로토콜 정보 확인 후 포트번호 세팅
		if layerCnt>=4 and dictionary.protocol_list[2]=="TCP":
			src_port=str(function.hex_to_dec(function.change_endian(dictionary.tcp_pkt['src_port'])))
			dst_port=str(function.hex_to_dec(function.change_endian(dictionary.tcp_pkt['dest_port'])))
		elif layerCnt>=4 and dictionary.protocol_list[2]=="UDP":
			src_port=str(function.hex_to_dec(function.change_endian(dictionary.udp_pkt['src_port'])))
			dst_port=str(function.hex_to_dec(function.change_endian(dictionary.udp_pkt['dest_port'])))
		else:
			src_port=""
			dst_port=""
		
		####################통계 정보 추출####################
		##Host맥주소가 입력 되었을 때 Inbound/Outbound 판별 및 카운트
		if flag_add!="":
			# 현재 패킷의 In/Out 구별
			io_flag=""
			if src_mac==flag_add and dst_mac!=flag_add:
				io_flag="outbound"
				dictionary.io_cnt[io_flag]+=1
			elif dst_mac==flag_add and src_mac!=flag_add:
				io_flag="inbound"
				dictionary.io_cnt[io_flag]+=1
		##Host맥주소가 입력되지 않았을 때 Host 맥주소를 판별하기 위해 덤프파일 내의 맥주소 그룹화 및 카운트
		elif flag_add=="":
			# Src mac 카운트
			if src_mac in dictionary.src_mac_cnt_s:
				dictionary.src_mac_cnt_s[src_mac]+=1
			else:
				dictionary.src_mac_cnt_s[src_mac]=1

			if src_mac in dictionary.all_mac_cnt_s:
				dictionary.all_mac_cnt_s[src_mac]+=1
			else:
				dictionary.all_mac_cnt_s[src_mac]=1

			# Dest IP 카운트
			if dst_mac in dictionary.dest_mac_cnt_s:
				dictionary.dest_mac_cnt_s[dst_mac]+=1
			else:
				dictionary.dest_mac_cnt_s[dst_mac]=1

			if dst_mac in dictionary.all_mac_cnt_s:
				dictionary.all_mac_cnt_s[dst_mac]+=1
			else:
				dictionary.all_mac_cnt_s[dst_mac]=1

		##Time chart 구성
		#  시간대별 패킷 수 카운트
		if function.hex_to_dec(time_sec) in dictionary.time_cnt:
			dictionary.time_cnt[function.hex_to_dec(time_sec)]+=1
		else:
			dictionary.time_cnt[function.hex_to_dec(time_sec)]=1


		##프로토콜 TOP5를 위한 카운트
		dictionary.protocol_cnt_s[dictionary.protocol_list[layerCnt-2]]+=1
		
		
		##Flow Data 구성(Host맥주소가 입력 되었을 때와 아닐때로 나뉜다)
		if flag_add!="":
			if io_flag!="":
				flow_qry+="('','"+userid+"','"+datetime.datetime.fromtimestamp(function.hex_to_dec(time_sec)).strftime("%Y-%m-%d %H:%M:%S")+"','"+src_add+"','"+src_port+"','"+dst_add+"','"+dst_port+"','"
				flow_qry+=dictionary.protocol_list[layerCnt-2]+"','"+str(function.hex_to_dec(pkt_length))+"','"+io_flag[0]+"',"+str(frame_num)+"),"
			else:
				flow_qry+="('','"+userid+"','"+datetime.datetime.fromtimestamp(function.hex_to_dec(time_sec)).strftime("%Y-%m-%d %H:%M:%S")+"','"+src_add+"','"+src_port+"','"+dst_add+"','"+dst_port+"','"
				flow_qry+=dictionary.protocol_list[layerCnt-2]+"','"+str(function.hex_to_dec(pkt_length))+"','',"+str(frame_num)+"),"
		elif flag_add=="":
			flow_qry+="('','"+userid+"','"+datetime.datetime.fromtimestamp(function.hex_to_dec(time_sec)).strftime("%Y-%m-%d %H:%M:%S")+"','"+src_add+"','"+src_port+"','"+dst_add+"','"+dst_port+"','"
			flow_qry+=dictionary.protocol_list[layerCnt-2]+"','"+str(function.hex_to_dec(pkt_length))+"','',"+str(frame_num)+"),"
		
		# Flow Qry에 5000개마다 구분자 삽입
		if frame_num%5000==0:
			flow_qry=flow_qry.rstrip(",")
			flow_qry+='@'

		##Geomap 데이터를 위한 값(dest ip를 기준으로 트래픽을 계산한 값을 구조화)
		# 사설 IP 대역 제외
		if layerCnt>=3 and dictionary.protocol_list[1]=="IPv4":
			if (orgin_dst[0]==10) or (orgin_dst[0]==172 and orgin_dst[1]>=16 and orgin_dst[1]<=31) or (orgin_dst[0]==192 and orgin_dst[1]==168):
				pass
			else:
				if dst_add in dictionary.geomap_cnt_s:
					dictionary.geomap_cnt_s[dst_add]+=1
				else:
					dictionary.geomap_cnt_s[dst_add]=1
		elif layerCnt>=3 and dictionary.protocol_list[1]=="IPv6":
			if dst_add in dictionary.geomap_cnt_s:
				dictionary.geomap_cnt_s[dst_add]+=1
			else:
				dictionary.geomap_cnt_s[dst_add]=1

	flow_qry=flow_qry.rstrip(",")


	##Protocol Top5 구조화
	# 프로토콜 카운트 정보 내림차순 정렬
	sorted_cnt=sorted(dictionary.protocol_cnt_s.items(), key=operator.itemgetter(1), reverse=True)	
	protocol_qry=""
	protocol_qry+="('','"+userid+"','"+sorted_cnt[0][0]+"',"+str(sorted_cnt[0][1])+"),"
	protocol_qry+="('','"+userid+"','"+sorted_cnt[1][0]+"',"+str(sorted_cnt[1][1])+"),"
	protocol_qry+="('','"+userid+"','"+sorted_cnt[2][0]+"',"+str(sorted_cnt[2][1])+"),"
	protocol_qry+="('','"+userid+"','"+sorted_cnt[3][0]+"',"+str(sorted_cnt[3][1])+"),"
	protocol_qry+="('','"+userid+"','"+sorted_cnt[4][0]+"',"+str(sorted_cnt[4][1])+")"
	

	##Geomap 데이터 구조화
	# 국가코드 매칭
	dictionary.geomap_cnt_s=sorted(dictionary.geomap_cnt_s.items(), key=operator.itemgetter(1), reverse=True)
	geo_temp={}
	geo_length=len(dictionary.geomap_cnt_s)
	i=0;
	while i<geo_length:
		dest_add=dictionary.geomap_cnt_s[i][0]

		req_url='http://whois.kisa.or.kr/openapi/ipascc.jsp?query='
		req_url+=dest_add
		req_url+='&key=2016060114100700583840&answer=json'
		
		html=urllib.request.urlopen(req_url)

		res_data=html.read().strip().decode('ascii')
		res_data=res_data.replace('{"whois":',"")
		res_data=res_data.replace("}}","}")
		jsonData=json.loads(res_data)

		geo_key=jsonData['countryCode']
		
		if geo_key!="none":
			if geo_key in geo_temp:
				geo_temp[geo_key]+=dictionary.geomap_cnt_s[i][1]
			else:
				geo_temp[geo_key]=dictionary.geomap_cnt_s[i][1]
		i+=1
	
	
	# DB삽입 쿼리문 구조화
	geo_temp=sorted(geo_temp.items(), key=operator.itemgetter(1), reverse=True)
	i=0
	geo_length=len(geo_temp)
	geo_qry=""
	while i<geo_length:
		geo_qry+="('','"+userid+"','"+geo_temp[i][0]+"',"+str(geo_temp[i][1])+"),"
		i+=1
	geo_qry=geo_qry.rstrip(",")


	##I/O 데이터 구조화
	# Host MAC주소를 입력 받은 경우
	if flag_add!="":
		io_qry="('','"+userid+"',"+str(dictionary.io_cnt['inbound'])+","
		io_qry+=str(dictionary.io_cnt['outbound'])+")"
	# Host MAC 주소를 입력받지 않은 경우
	elif flag_add=="":
		# src, dest 및 모든 맥주소 카운트값 내림차순 정렬
		dictionary.all_mac_cnt_s=sorted(dictionary.all_mac_cnt_s.items(), key=operator.itemgetter(1), reverse=True)	
		
		# 기준 맥주소 정하기
		flag_add=dictionary.all_mac_cnt_s[0][0]

		# Inbound/Outbound 카운트 값 세팅
		try:
			dictionary.io_cnt['inbound']=dictionary.dest_mac_cnt_s[flag_add]
			dictionary.io_cnt['outbound']=dictionary.src_mac_cnt_s[flag_add]
		except:
			pass

		
		# 데이터 구조화
		io_qry="('','"+userid+"',"+str(dictionary.io_cnt['inbound'])+","
		io_qry+=str(dictionary.io_cnt['outbound'])+")"


	##timechart 데이터 구조화
	time_key=sorted(list(dictionary.time_cnt))
	timeKey_length=len(time_key)
	i=0
	timeline_qry=""
	while i<timeKey_length:
		timeline_qry+="('','"+userid+"','"+datetime.datetime.fromtimestamp(time_key[i]).strftime("%H:%M:%S")+"',"+str(dictionary.time_cnt[time_key[i]])+"),"
		i+=1
	timeline_qry=timeline_qry.rstrip(",")


	##복원부분(정규표현식으로 바꾸기)
	# 브라우저별 바운더리 형식
	try:
		ie="7e"
		chrome_safari="WebKitFormBoundary"
		
		# 복원디렉토리 생성
		if compile_mode==2:
			dir_name='/var/www/html/restore/'
			now_date=datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d')

			if not os.path.isdir(dir_name+str(now_date)):
				os.mkdir(dir_name+str(now_date))

			dir_name+=now_date+"/"+userid
			if not os.path.isdir(dir_name):
				os.mkdir(dir_name)

			dir_name+='/'

		# tcp_stream별로 분석 후 복원작업
		# 스트림데이터를 라인별로 끊어서 반복수행
		tcp_stream_key=list(dictionary.tcp_stream_dic.keys())
		tcp_stream_cnt=len(tcp_stream_key)
		i=0
		while i<tcp_stream_cnt:
			file_name=""
			temp_key=tcp_stream_key[i]
			ascii_data=function.hex_to_ascii(dictionary.tcp_stream_dic[temp_key])
			if ascii_data != -1:
				start_offset=0
				end_offset=0
				split_ascii=ascii_data.splitlines()
				split_length=len(split_ascii)
				j=0
				while j<split_length:
					# offset 계산
					start_offset+=len(split_ascii[j])
					try:
						if dictionary.tcp_stream_dic[temp_key][start_offset]==0xd and dictionary.tcp_stream_dic[temp_key][start_offset+1]==0xa:
							start_offset+=2
						elif dictionary.tcp_stream_dic[temp_key][start_offset]==0xd:
							start_offset+=1
						elif dictionary.tcp_stream_dic[temp_key][start_offset]==0xa:
							start_offset+=1
					except:
						pass
					# 시작바운더리 체크
					if split_ascii[j].find(chrome_safari)!=-1 or split_ascii[j].find(ie)!=-1:
						if split_ascii[j+1].find('filename="')!=-1:
							# 파일이름 파싱
							filename_offset=split_ascii[j+1].find('filename="')+10
							str_length=len(split_ascii[j+1])
							while filename_offset<str_length-1:
								file_name+=split_ascii[j+1][filename_offset]
								filename_offset+=1

							# offset 계산
							start_offset+=len(split_ascii[j+1])
							if dictionary.tcp_stream_dic[temp_key][start_offset]==0xd and dictionary.tcp_stream_dic[temp_key][start_offset+1]==0xa:
								start_offset+=2
							elif dictionary.tcp_stream_dic[temp_key][start_offset]==0xd:
								start_offset+=1
							elif dictionary.tcp_stream_dic[temp_key][start_offset]==0xa:
								start_offset+=1

							start_offset+=len(split_ascii[j+2])
							if dictionary.tcp_stream_dic[temp_key][start_offset]==0xd and dictionary.tcp_stream_dic[temp_key][start_offset+1]==0xa:
								start_offset+=2
							elif dictionary.tcp_stream_dic[temp_key][start_offset]==0xd:
								start_offset+=1
							elif dictionary.tcp_stream_dic[temp_key][start_offset]==0xa:
								start_offset+=1

							start_offset+=len(split_ascii[j+3])
							if dictionary.tcp_stream_dic[temp_key][start_offset]==0xd and dictionary.tcp_stream_dic[temp_key][start_offset+1]==0xa:
								start_offset+=2
							elif dictionary.tcp_stream_dic[temp_key][start_offset]==0xd:
								start_offset+=1
							elif dictionary.tcp_stream_dic[temp_key][start_offset]==0xa:
								start_offset+=1
							j+=4

							flag=0
							end_offset=start_offset
							while j<split_length:
								# 끝 바운더리 체크
								if split_ascii[j].find(chrome_safari)!=-1 or split_ascii[j].find(ie)!=-1 and split_ascii[j][-2:]=="--":								
									flag=1

									# 파일 복원
									if compile_mode==1:
										f=open(file_name,"wb")
									if compile_mode==2:
										f=open(dir_name+file_name,"wb")
									while 1:
										if dictionary.tcp_stream_dic[temp_key][start_offset]==0xd and dictionary.tcp_stream_dic[temp_key][start_offset+1]==0xa and dictionary.tcp_stream_dic[temp_key][start_offset+2]==0x2d:
											break									
										else:
											f.write(dictionary.tcp_stream_dic[temp_key][start_offset].to_bytes(1, 'little'))
										start_offset+=1
									f.close()
									break;
								else:
									# offset 계산
									end_offset+=len(split_ascii[j])
																
									if dictionary.tcp_stream_dic[temp_key][end_offset]==0xd and dictionary.tcp_stream_dic[temp_key][end_offset+1]==0xa:
										end_offset+=2
									elif dictionary.tcp_stream_dic[temp_key][end_offset]==0xd:
										end_offset+=1
									elif dictionary.tcp_stream_dic[temp_key][end_offset]==0xa:
										end_offset+=1
									j+=1
							
							if flag==1: 
								break;
					j+=1
			i+=1
	except:
		pass
	
	##업로드 파일 삭제 및 json 출력
	if compile_mode==2:
		os.remove(fpath)
		sys.stdout.write(userid+";"+flow_qry+";"+protocol_qry+";"+geo_qry+";"+io_qry+";"+timeline_qry+";"+dir_name)

	##실행시간 출력
	if compile_mode==1:
		t2 = time.time() # end time
		sys.stdout.write("\n실행시간:")
		print(t2-t1)
	
else:
	print("해당 덤프파일의 2계층 프로토콜 분석을 지원하지 않습니다.")
	sys.exit()