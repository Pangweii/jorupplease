"""""""""""""""""""""""""""""""""
프로그램에서 사용할
변수 및 리스트 정의

"""

##하나의 패킷에 대한 계층별 프로토콜 정보
protocol_list=[]




"""""""""""""""""""""""""""""""""
프로그램에서 사용할
딕셔너리를 정의

"""
## Global Header
pcap_hdr_s={
	'magic_number':[],
	'version_major':[],
	'version_minor':[],
	'thiszone':[],
	'sigfigs':[],
	'snaplen':[],
	'network':[]
}

## Packet(Record) Header
pkt_hdr_s={
	'ts_sec':[],
	'ts_usec':[],
	'incl_len':[],
	'orig_len':[]
}

eth_frame={
	'des_mac':[],
	'src_mac':[],
	'type_length':[],
	'data':[],
	'padding':[]
}

arp_pkt={
	'hardware_type':[],
	'protocol_type':[],
	'hardware_size':[],
	'protocol_size':[],
	'opcode':[],
	'sender_mac':[],
	'sender_ip':[],
	'target_mac':[],
	'target_ip':[]
}

ipv4_pkt={
	'ip_hl':0,
	'ip_v':0,
	'ip_tos':0,
	'ip_len':[],
	'ip_id':[],
	'flags':0,
	'ip_off':0,
	'ip_ttl':0,
	'ip_p':[],
	'ip_sum':[],
	'ip_src':[],
	'ip_dst':[],
	'option':[],
	'data':[]
}

ipv6_pkt={
	'version':0,
	'traffic_class':0,
	'flow_l':0,
	'payload_len':[],
	'next_h':-1,
	'h_limit':-1,
	'src_add':[],
	'dest_add':[],
	'data':[]
}

tcp_pkt={
	'src_port':[],
	'dest_port':[],
	'seq_num':[],
	'ack_num':[],
	'hl':0,
	'reserved':0,
	'flags':0,
	'window_sz':[],
	'chk_sum':[],
	'urgent_p':[],
	'opt_pad':[],
	'data':[]
}

udp_pkt={
	'src_port':[],
	'dest_port':[],
	'length':[],
	'chk_sum':[],
	'data':[]
}

icmp_pkt={
	'type':0,
	'code':0,
	'chk_sum':[],
	'id':[],
	'seq_num':[],
	'data':[]
}

## flow의 hex값을 나타내기 위한 딕셔너리
flow_hex={
	'hfrm_num':[],
	'htime':[],
	'hsrc_ip':[],
	'hdest_ip':[],
	'hsrc_port':[],
	'hdest_port':[],
	'hprotocol':[],
	'hlength':[]
}

## 프로토콜 별 카운트 값
#  초기 값은 0으로 세팅
protocol_cnt_s={
	'Ethernet':0,
	'ARP':0,
	'IPv4':0,
	'IPv6':0,
	'ICMP':0,
	'TCP':0,
	'UDP':0,
	'HTTP':0,
	'FTP':0,
	'SSH':0,
	'SMTP':0,
	'POP':0,
	'TELNET':0,
	'DNS':0,
	'HTTPS':0,
	'TFTP':0,
	'SNMP':0,
	'BGP':0,
	'ECHO':0,
	'DAYTIME':0,
	'DHCP':0,
	'NetBIOS':0,
	'Finger':0,
	'IMAP4':0,
	'LDAP':0,
	'MSSQL':0,
	'OracleDB':0,
	'MySQL':0,
	'RDP':0,
	'SVN':0,
	'PPAS':0,
}

##I/O Count Dictionary
io_cnt={
	'inbound':0,
	'outbound':0
}
all_mac_cnt_s={}
src_mac_cnt_s={}
dest_mac_cnt_s={}

##Geomap 딕셔너리
geomap_cnt_s={}

##같은 Time 값끼리 Count하는 딕셔너리
time_cnt={}

##복원을 위한 스트림데이터를 모아놓은 딕셔너리
tcp_stream_dic={}
