import sys
import dictionary

def readfile(file_path):
	file=open(file_path,"rb")
	byteBuffer=bytearray(file.read())

	return byteBuffer


##big endian 기준
def hex_to_dec(hexlist):
	_len=len(hexlist)
	if _len==1:
		return hexlist[0]
	else:
		i=_len-1
		decvalue=0
		while i>=0:
			decvalue=decvalue<<8
			decvalue=decvalue|hexlist[i]
			i=i-1

		return decvalue

##Endian 변환
def change_endian(hexlist):
	_len=len(hexlist)
	change_list=[]
	if _len==1:
		return hexlist[0]
	else:
		i=_len-1
		while i>=0:
			change_list.append(hexlist[i])
			i=i-1
		return change_list


def next_pkt_chk(_offset, byteBuffer):
	if len(byteBuffer)-1 >= _offset:
		return 1
	else:
		return 0

"""
Description:
File의 Magic Number를 이용해
정상적인 덤프파일인지 판별하는 함수

* pcap-ng 판별루틴 추가 예정

return:
1 : pcap 파일
0 : magic_number 불일치 파일
"""
def chk_file(byteBuffer):
	##Magic Number Check
	i=1
	mgcNum_buffer=[]
	mgcNum_pcap=[0xD4, 0xC3, 0xB2, 0xA1]

	for val in byteBuffer:
		if i % 5 == 0:
			if mgcNum_buffer==mgcNum_pcap:
				return 1
			else:
				return 0

		mgcNum_buffer.append(val)
		i=i+1


"""
* pcap-ng 추가 예정
Description:
	덤프파일을 Byte단위로 읽어온 후
	Global Header를 파싱하여 딕셔너리에 파싱결과를
	저장한 후 해당 딕셔너리를 반환하는 함수
Parameter:
	file_path: 분석할 파일의 경로
	file_type: 파일 타입(1이면 pcap, 2면 pcap-ng)
return:
	현재까지 읽은 offset 값(24)
"""
def parse_ghdr(file_type, byteBuffer):	
	##Pcap File
	if file_type == 1:
		i=0
		while i <= 25:
			if i>=0 and i<=3:
				dictionary.pcap_hdr_s['magic_number'].append(byteBuffer[i])

			elif i>=4 and i<=5:
				dictionary.pcap_hdr_s['version_major'].append(byteBuffer[i])

			elif i>=6 and i<=7:
				dictionary.pcap_hdr_s['version_minor'].append(byteBuffer[i])

			elif i>=8 and i<=11:
				dictionary.pcap_hdr_s['thiszone'].append(byteBuffer[i])

			elif i>=12 and i<=15:
				dictionary.pcap_hdr_s['sigfigs'].append(byteBuffer[i])

			elif i>=16 and i<=19:
				dictionary.pcap_hdr_s['snaplen'].append(byteBuffer[i])

			elif i>=20 and i<=23:
				dictionary.pcap_hdr_s['network'].append(byteBuffer[i])
			
			else:
				# offset return
				return 24
			i=i+1

def parse_rhdr(_offset, byteBuffer):
	rhdr_temp={
		'ts_sec':[],
		'ts_usec':[],
		'incl_len':[],
		'orig_len':[]
	}
	i=0
	while i <= 16:
		if i>=0 and i<=3:
			rhdr_temp['ts_sec'].append(byteBuffer[_offset+i])
		elif i>=4 and i<=7:
			rhdr_temp['ts_usec'].append(byteBuffer[_offset+i])
		elif i>=8 and i<=11:
			rhdr_temp['incl_len'].append(byteBuffer[_offset+i])
		elif i>=12 and i<=15:
			rhdr_temp['orig_len'].append(byteBuffer[_offset+i])

		i=i+1
	
	dictionary.pkt_hdr_s=rhdr_temp;
	return _offset+16;

def get_pktdata_length(snaplen, incl_len, orig_len):
	if incl_len == orig_len:
		return incl_len
	elif incl_len != orig_len:
		return snaplen

def read_rdata(_offset, byteBuffer, data_length):
	rdata=[]
	i=0
	while i<data_length:
		rdata.append(byteBuffer[_offset+i])
		i=i+1

	return rdata

def parse_ethernet(rdata, rdata_offset):
	eth_temp={
		'des_mac':[],
		'src_mac':[],
		'type_length':[],
		'data':[],
		'padding':[]
	}
	i=0
	rdata_length=len(rdata)
	while i<rdata_length:
		if i>=0 and i<=5:
			eth_temp['des_mac'].append(rdata[rdata_offset+i])
		elif i>=6 and i<=11:
			eth_temp['src_mac'].append(rdata[rdata_offset+i])
		elif i>=12 and i<=13:
			eth_temp['type_length'].append(rdata[rdata_offset+i])
		else:
			eth_temp['data'].append(rdata[rdata_offset+i])

		i=i+1
	
	##padding 판별용 변수
	# 실제 ethernet frame의 data필드에서 상위 프로토콜 데이터정보의 길이
	real_length=0

	##현재 계층의 프로토콜 정보 삽입
	# append 함수를 통해 호출하기 때문에 제일 하위계층에서 초기화 작업을 해주어야한다.
	temp=[]
	dictionary.protocol_list=temp
	dictionary.protocol_list.append("Ethernet")
	
	##ethernet frame의 type/length값(상위 프로토콜 구분)에 따라 프로토콜별 파싱함수 호출
	# arp 프로토콜
	if eth_temp['type_length']==[0x08, 0x06]:
		real_length=parse_arp(eth_temp['data'])

	# ip_v4 프로토콜
	elif eth_temp['type_length']==[0x08, 0x00]:
		real_length=parse_ipv4(eth_temp['data'])
	
	# ip_v6 프로토콜
	elif eth_temp['type_length']==[0x86, 0xDD]:
		real_length=parse_ipv6(eth_temp['data'])

	
	# Padding 계산 후 삽입
	"""
	withoutPaddingLength=len(eth_temp['des_mac'])+len(eth_temp['src_mac'])+len(eth_temp['type_length'])+real_length
	sys.stdout.write("real_length:")
	dictionary.now_protocol(real_length)
	if rdata_length==60 and rdata_length>withoutPaddingLength and real_length!=0:
		dictionary.now_protocol("padding존재")
	"""
	
	dictionary.eth_frame=eth_temp

def parse_arp(_data):
	arp_pkt_temp={
		'hardware_type':[],
		'protocol_type':[],
		'hardware_size':[],
		'protocol_size':[],
		'opcode':[],
		'sender_mac':[],
		'sender_ip':[],
		'target_mac':[],
		'target_ip':[]
	}
	
	arp_pkt_temp['hardware_type'].append(_data[0])
	arp_pkt_temp['hardware_type'].append(_data[1])
	arp_pkt_temp['protocol_type'].append(_data[2])
	arp_pkt_temp['protocol_type'].append(_data[3])
	arp_pkt_temp['hardware_size'].append(_data[4])
	arp_pkt_temp['protocol_size'].append(_data[5])
	arp_pkt_temp['opcode'].append(_data[6])
	arp_pkt_temp['opcode'].append(_data[7])

	_offset=8
	i=0
	while i<hex_to_dec(arp_pkt_temp['hardware_size']):
		arp_pkt_temp['sender_mac'].append(_data[_offset+i])
		i=i+1
	
	_offset=_offset+hex_to_dec(arp_pkt_temp['hardware_size'])
	
	i=0
	while i<hex_to_dec(arp_pkt_temp['protocol_size']):
		arp_pkt_temp['sender_ip'].append(_data[_offset+i])
		i=i+1
		
	_offset=_offset+hex_to_dec(arp_pkt_temp['protocol_size'])
	
	i=0
	while i<hex_to_dec(arp_pkt_temp['hardware_size']):
		arp_pkt_temp['target_mac'].append(_data[_offset+i])
		i=i+1
	
	_offset=_offset+hex_to_dec(arp_pkt_temp['hardware_size'])

	i=0
	while i<hex_to_dec(arp_pkt_temp['protocol_size']):
		arp_pkt_temp['target_ip'].append(_data[_offset+i])
		i=i+1
	
	# offset 계산
	_offset=_offset+hex_to_dec(arp_pkt_temp['protocol_size'])
	
	# 분석된 데이터 삽입
	dictionary.arp_pkt=arp_pkt_temp

	# 현재 계층의 프로토콜 정보 삽입
	dictionary.protocol_list.append("ARP")

	# Ethernet Padding 값 추출을 위해 지금까지 읽은 비트 수 반환
	return _offset

def parse_ipv4(_data):
	ipv4_pkt_temp={
		'ip_v':0,
		'ip_hl':0,
		'ip_tos':0,
		'ip_len':[],
		'ip_id':[],
		'flags':0,
		'ip_off':0,
		'ip_ttl':0,
		'ip_p':0,
		'ip_sum':[],
		'ip_src':[],
		'ip_dst':[],
		'option':[],
		'data':[]
	}
	# 읽은 바이트 수
	_offset=0

	##Header Length와 version정보 파싱
	# data read
	hl_and_v=_data[_offset]
	_offset=_offset+1

	# 상위 4비트, 하위 4비트 쪼개기
	temp=hl_and_v>>4
	ipv4_pkt_temp['ip_v']=temp
	temp=temp<<4
	ipv4_pkt_temp['ip_hl']=(temp^hl_and_v)*4
	
	# fragment offset 변수
	frag_offset=[]

	# ip header 파싱
	while _offset<ipv4_pkt_temp['ip_hl']:
		if _offset==1:
			ipv4_pkt_temp['ip_tos']=_data[_offset]
		elif _offset>=2 and _offset<=3:
			ipv4_pkt_temp['ip_len'].append(_data[_offset])
		elif _offset>=4 and _offset<=5:
			ipv4_pkt_temp['ip_id'].append(_data[_offset])
		elif _offset>=6 and _offset<=7:
			frag_offset.append(_data[_offset])
		elif _offset==8:
			ipv4_pkt_temp['ip_ttl']=_data[_offset]
		elif _offset==9:
			ipv4_pkt_temp['ip_p']=_data[_offset]
		elif _offset>=10 and _offset<=11:
			ipv4_pkt_temp['ip_sum'].append(_data[_offset])
		elif _offset>=12 and _offset<=15:
			ipv4_pkt_temp['ip_src'].append(_data[_offset])
		elif _offset>=16 and _offset<=19:
			ipv4_pkt_temp['ip_dst'].append(_data[_offset])
		else:
			ipv4_pkt_temp['option'].append(_data[_offset])

		_offset=_offset+1
	
	# flag, fragment offset 분할 후 삽입
	temp=hex_to_dec(change_endian(frag_offset))
	ipv4_pkt_temp['flags']=temp>>13
	ipv4_pkt_temp['ip_off']=hex_to_dec(change_endian(frag_offset))^temp

	# ip data 부분 파싱
	total_len=len(_data)
	while _offset<total_len:
		ipv4_pkt_temp['data'].append(_data[_offset])
		_offset=_offset+1
	
	# 분석된 데이터 삽입
	dictionary.ipv4_pkt=ipv4_pkt_temp
	
	# 현재 계층의 프로토콜 정보 삽입
	dictionary.protocol_list.append("IPv4")

	if ipv4_pkt_temp['ip_p']==1:
		_offset=_offset+parse_icmp(ipv4_pkt_temp['data'])
	elif ipv4_pkt_temp['ip_p']==6:
		_offset=_offset+parse_tcp("ipv4", ipv4_pkt_temp['data'])
	elif ipv4_pkt_temp['ip_p']==17:
		_offset=_offset+parse_udp("ipv4", ipv4_pkt_temp['data'])

	
	# 읽은 byte 수 리턴
	return _offset


##확장헤더 개발안됨 ㅎ
def parse_ipv6(_data):
	ipv6_pkt_temp={
		'version':0,
		'traffic_class':0,
		'flow_l':0,
		'payload_len':[],
		'next_h':-1,
		'h_limit':-1,
		'src_add':[],
		'dest_add':[],
		'data':[]
	}

	_offset=0		  # 읽은 바이트 수
	v_traffic_flow=[] # version과 traffic, flow lable필드 분리 전 데이터
	
	##ip_v6 header 파싱
	ipv6_length=len(_data)
	while _offset<ipv6_length:
		if _offset>=0 and _offset<=3:
			v_traffic_flow.append(_data[_offset])
		elif _offset>=4 and _offset<=5:
			ipv6_pkt_temp['payload_len'].append(_data[_offset])
		elif _offset==6:
			ipv6_pkt_temp['next_h']=_data[_offset]
		elif _offset==7:
			ipv6_pkt_temp['h_limit']=_data[_offset]
		elif _offset>=8 and _offset<=23:
			ipv6_pkt_temp['src_add'].append(_data[_offset])
		elif _offset>=24 and _offset<=39:
			ipv6_pkt_temp['dest_add'].append(_data[_offset])
		else:
			ipv6_pkt_temp['data'].append(_data[_offset])

		_offset=_offset+1
	
	##version과 traffic, flow lable필드 분리
	temp=hex_to_dec(change_endian(v_traffic_flow))
	ipv6_pkt_temp['version']=temp>>28
	temp=(ipv6_pkt_temp['version']<<28)^temp
	ipv6_pkt_temp['traffic_class']=temp>>20
	temp=(ipv6_pkt_temp['traffic_class']<<20)^temp
	ipv6_pkt_temp['flow_l']=temp


	# 분석된 데이터 삽입
	dictionary.ipv6_pkt=ipv6_pkt_temp
	
	# 현재 계층의 프로토콜 정보 삽입
	dictionary.protocol_list.append("IPv6")

	if ipv6_pkt_temp['next_h']==2:
		_offset=_offset+parse_icmp(ipv6_pkt_temp['data'])
	elif ipv6_pkt_temp['next_h']==6:
		_offset=_offset+parse_tcp("ipv6", ipv6_pkt_temp['data'])
	elif ipv6_pkt_temp['next_h']==17:
		_offset=_offset+parse_udp("ipv6", ipv6_pkt_temp['data'])

	# 읽은 byte 수 리턴
	return _offset


def parse_icmp(_data):
	icmp_pkt_temp={
		'type':0,
		'code':0,
		'chk_sum':[],
		'id':[],
		'seq_num':[],
		'data':[]
	}
	
	_offset=0 # 읽은 바이트 수
	
	##icmp packet parsing
	# icmp의 경우 상위계층 프로토콜이 존재하지 않으므로 data까지 한번에 파싱
	icmp_length=len(_data)
	while _offset<icmp_length:
		if _offset==0:
			icmp_pkt_temp['type']=_data[_offset]
		elif _offset==1:
			icmp_pkt_temp['code']=_data[_offset]
		elif _offset>=2 and _offset<=3:
			icmp_pkt_temp['chk_sum'].append(_data[_offset])
		elif _offset>=4 and _offset<=5:
			icmp_pkt_temp['id'].append(_data[_offset])
		elif _offset>=6 and _offset<=7:
			icmp_pkt_temp['seq_num'].append(_data[_offset])
		else:
			icmp_pkt_temp['data'].append(_data[_offset])
		
		_offset=_offset+1

	# 현재 계층의 프로토콜 정보 삽입
	dictionary.protocol_list.append("ICMP")
	
	# 분석된 데이터 삽입
	icmp_pkt=icmp_pkt_temp

	# 읽은 byte 수 리턴
	return _offset


def parse_tcp(prev_p, _data):
	tcp_pkt_temp={
		'src_port':[],
		'dest_port':[],
		'seq_num':[],
		'ack_num':[],
		'hl':0,
		'reserved':0,
		'flags':0,
		'window_sz':[],
		'chk_sum':[],
		'urgent_p':[],
		'opt_pad':[],
		'data':[]
	}
	_offset=0   # 읽은 바이트 수
	hl_resrv=0 # header length와 reserved 필드를 분리하기 전 상태

	##tcp header 파싱
	while _offset<20:
		if _offset>=0 and _offset<=1:
			tcp_pkt_temp['src_port'].append(_data[_offset])
		elif _offset>=2 and _offset<=3:
			tcp_pkt_temp['dest_port'].append(_data[_offset])
		elif _offset>=4 and _offset<=7:
			tcp_pkt_temp['seq_num'].append(_data[_offset])
		elif _offset>=8 and _offset<=11:
			tcp_pkt_temp['ack_num'].append(_data[_offset])
		elif _offset==12:
			hl_resrv=_data[_offset]
		elif _offset==13:
			tcp_pkt_temp['flags']=_data[_offset]
		elif _offset>=14 and _offset<=15:
			tcp_pkt_temp['window_sz'].append(_data[_offset])
		elif _offset>=16 and _offset<=17:
			tcp_pkt_temp['chk_sum'].append(_data[_offset])
		elif _offset>=18 and _offset<=19:
			tcp_pkt_temp['urgent_p'].append(_data[_offset])
		
		_offset=_offset+1


	##hl_resrv 분할 후 header length 및 reserved 구하기
	tcp_pkt_temp['hl']=(hl_resrv>>4)
	hl_resrv=(tcp_pkt_temp['hl']<<4)^hl_resrv
	tcp_pkt_temp['reserved']=hl_resrv
	tcp_pkt_temp['hl']=tcp_pkt_temp['hl']*4
	
	##option 및 padding 데이터 존재여부 확인 후 파싱
	if tcp_pkt_temp['hl']>20:
		while _offset<tcp_pkt_temp['hl']:
			tcp_pkt_temp['opt_pad'].append(_data[_offset])
			_offset=_offset+1

	##tcp data 필드 파싱
	tcp_length=len(_data)
	while _offset<tcp_length:
		tcp_pkt_temp['data'].append(_data[_offset])
		_offset=_offset+1
	
	# 패킷 조립 함수 호출
	if prev_p=="ipv4":
		assemble_stream("tcp", dictionary.ipv4_pkt['ip_src'], dictionary.ipv4_pkt['ip_dst'], tcp_pkt_temp['src_port'], tcp_pkt_temp['dest_port'], tcp_pkt_temp['data'])
	elif prev_p=="ipv6":
		assemble_stream("tcp", dictionary.ipv6_pkt['src_add'], dictionary.ipv6_pkt['dest_add'], tcp_pkt_temp['src_port'], tcp_pkt_temp['dest_port'], tcp_pkt_temp['data'])

	# 분석된 데이터 삽입
	dictionary.tcp_pkt=tcp_pkt_temp

	# 현재 계층의 프로토콜 정보 삽입
	dictionary.protocol_list.append("TCP")

	# 포트번호를 통해 다음계층의 프로토콜정보를 확인
	chkProtocolByPort(hex_to_dec(change_endian(tcp_pkt_temp['src_port'])), hex_to_dec(change_endian(tcp_pkt_temp['dest_port'])), dictionary.tcp_pkt['data'])

	# 읽은 byte 수 리턴
	return _offset


def parse_udp(prev_p, _data):
	udp_pkt_temp={
		'src_port':[],
		'dest_port':[],
		'length':[],
		'chk_sum':[],
		'data':[]
	}

	_offset=0   # 읽은 바이트 수
	
	##udp header 파싱
	while _offset<8:
		if _offset>=0 and _offset<=1:
			udp_pkt_temp['src_port'].append(_data[_offset])
		elif _offset>=2 and _offset<=3:
			udp_pkt_temp['dest_port'].append(_data[_offset])
		elif _offset>=4 and _offset<=5:
			udp_pkt_temp['length'].append(_data[_offset])
		elif _offset>=6 and _offset<=7:
			udp_pkt_temp['chk_sum'].append(_data[_offset])
		
		_offset=_offset+1

	##udp data 파싱
	udp_length=len(_data)
	while _offset<udp_length:
		udp_pkt_temp['data'].append(_data[_offset])
		_offset=_offset+1

	# 패킷 조립 함수 호출
	if prev_p=="ipv4":
		assemble_stream("udp", dictionary.ipv4_pkt['ip_src'], dictionary.ipv4_pkt['ip_dst'], udp_pkt_temp['src_port'], udp_pkt_temp['dest_port'], udp_pkt_temp['data'])
	elif prev_p=="ipv6":
		assemble_stream("udp", dictionary.ipv6_pkt['src_add'], dictionary.ipv6_pkt['dest_add'], udp_pkt_temp['src_port'], udp_pkt_temp['dest_port'], udp_pkt_temp['data'])

	# 분석된 데이터 삽입
	dictionary.udp_pkt=udp_pkt_temp
	
	# 현재 계층의 프로토콜 정보 삽입
	dictionary.protocol_list.append("UDP")

	# 포트번호를 통해 다음계층의 프로토콜정보를 확인
	chkProtocolByPort(hex_to_dec(change_endian(udp_pkt_temp['src_port'])), hex_to_dec(change_endian(udp_pkt_temp['dest_port'])), dictionary.udp_pkt['data'])
	
	# 읽은 byte 수 리턴
	return _offset


##포트번호를 통해 7계층 프로토콜 정보를 확인하는 함수
def chkProtocolByPort(SrcPort, DestPort, _data):
	# 현재 계층의 프로토콜 정보 삽입
	if SrcPort==80 or DestPort==80:
		dictionary.protocol_list.append("HTTP")

	elif SrcPort==20 or DestPort==20:
		dictionary.protocol_list.append("FTP")

	elif SrcPort==21 or DestPort==21:
		dictionary.protocol_list.append("FTP")

	elif SrcPort==22 or DestPort==22:
		dictionary.protocol_list.append("SSH")
	
	elif SrcPort==23 or DestPort==23:
		dictionary.protocol_list.append("TELNET")

	elif SrcPort==25 or DestPort==25:
		dictionary.protocol_list.append("SMTP")

	elif SrcPort==53 or DestPort==53:
		dictionary.protocol_list.append("DNS")

	elif SrcPort==110 or DestPort==110:
		dictionary.protocol_list.append("POP")

	elif SrcPort==443 or DestPort==443:
		dictionary.protocol_list.append("HTTPS")

	elif SrcPort==69 or DestPort==69:
		dictionary.protocol_list.append("TFTP")

	elif SrcPort==161 or DestPort==161:
		dictionary.protocol_list.append("SNMP")
		
	elif SrcPort==162 or DestPort==162:
		dictionary.protocol_list.append("SNMP")

	elif SrcPort==179 or DestPort==179:
		dictionary.protocol_list.append("BGP")
		
	elif SrcPort==7 or DestPort==7:
		dictionary.protocol_list.append("ECHO")
		
	elif SrcPort==13 or DestPort==13:
		dictionary.protocol_list.append("DAYTIME")
		
	elif SrcPort==68 or DestPort==68:
		dictionary.protocol_list.append("DHCP")
		
	elif SrcPort==67 or DestPort==67:
		dictionary.protocol_list.append("DHCP")
		
	elif SrcPort==139 or DestPort==139:
		dictionary.protocol_list.append("NetBIOS")
		
	elif SrcPort==79 or DestPort==79:
		dictionary.protocol_list.append("Finger")
				
	elif SrcPort==143 or DestPort==143:
		dictionary.protocol_list.append("IMAP4")
				
	elif SrcPort==389 or DestPort==389:
		dictionary.protocol_list.append("LDAP")
				
	elif SrcPort==1433 or DestPort==1433:
		dictionary.protocol_list.append("MSSQL")
				
	elif SrcPort==1521 or DestPort==1521:
		dictionary.protocol_list.append("OracleDB")
				
	elif SrcPort==3306 or DestPort==3306:
		dictionary.protocol_list.append("MySQL")
		
	elif SrcPort==3389 or DestPort==3389:
		dictionary.protocol_list.append("RDP")
		
	elif SrcPort==3690 or DestPort==3690:
		dictionary.protocol_list.append("SVN")
				
	elif SrcPort==5444 or DestPort==5444:
		dictionary.protocol_list.append("PPAS")


## TCP와 UDP의 통신패킷을 스트림별로 재조립
def assemble_stream(layer4_p, src_ip, dest_ip, src_port, dest_port, _data):
	if layer4_p=="tcp":
		stream_key1=str(hex_to_dec(src_ip))+str(hex_to_dec(dest_ip))+str(hex_to_dec(src_port))+str(hex_to_dec(dest_port))
		stream_key2=str(hex_to_dec(dest_ip))+str(hex_to_dec(src_ip))+str(hex_to_dec(dest_port))+str(hex_to_dec(src_port))
		
		if stream_key1 in dictionary.tcp_stream_dic:
			dictionary.tcp_stream_dic[stream_key1]+=_data
		elif stream_key2 in dictionary.tcp_stream_dic:
			dictionary.tcp_stream_dic[stream_key2]+=_data
		else:
			dictionary.tcp_stream_dic[stream_key1]=_data
	elif layer4_p=="udp":
		pass

def hex_to_ascii(_data):
	ascii_data=""
	if _data:
		i=0
		data_length=len(_data)
		while i<data_length:
			if _data[i]>0 and _data[i]<=127:
				ascii_data+=chr(_data[i])
			else:
				ascii_data+="."
			i+=1
		return ascii_data
	else:
		return -1