<?php
include 'db_login.php';
$conn = mysqli_connect($host, $id, $pw, $dbname);
if (mysqli_connect_errno()) {
    die('Connect Error: '.mysqli_connect_error());
}

?>
<html>
  <head>

    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
      <!-- 합쳐지고 최소화된 최신 CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">

  <!-- 부가적인 테마 -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap-theme.min.css">

  <!-- 합쳐지고 최소화된 최신 자바스크립트 -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js"></script>
  
  <!-- ajax 불러오기 -->
  <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
        
    <style>
    table{
      text-align:center;
    }

    </style>
  </head>
  <body>
  <table class = "table table-striped table-bordered table-hover" width=100% height=90%>
    <thead>
 
      <tr>
       <th style="text-align:center;">No</th>
        <th style="text-align:center;">Protocol</th>
        <th style="text-align:center;">Count</th>
      </tr>
    
    </thead>
    <tbody>
<?php

              
                $userid = $_COOKIE['userid'];
                $cnt=1;        
                $movep= "./sub_popup2.php";
                try{    
                  $check_val = "SELECT protocol AS pro, count FROM protocol WHERE id ='$userid' GROUP BY protocol ORDER BY count DESC";
                 
                  $first_qry = $conn->query($check_val);

                  


                 
                  while($cnt <= 5 ){
                  $first_qry2 = mysqli_fetch_array($first_qry);   
                     if($cnt == 1){
                      echo '<tr class="success">';
                     }else{
                      echo '<tr>';
                      } 
                      echo '<td>'.$cnt.'</td>';
                      echo '<td><a href="./sub_popup2.php?value='.$first_qry2['pro'].'" onclick="window.open(this.href,\'detail\',\'left=100,top=200,width=900,height=500\');return false;">'.$first_qry2['pro'].'</a></td>';

                      echo '<td>'.$first_qry2['count'].'</td>';
                      
                      echo '</tr>';
                   
                      $cnt +=1;
                    
                  }
                
                on_end_flush();
                mysql_close($conn);
                }catch(PDOException $e){
                  $message = '<script>alert($e->getMessage())</script>';
                }
    ?>
    </tbody>
  </table>
    

  </body>
</html>