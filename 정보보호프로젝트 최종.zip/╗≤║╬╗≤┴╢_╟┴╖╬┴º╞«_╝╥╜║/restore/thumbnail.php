<!-- 합쳐지고 최소화된 최신 CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">

	<!-- 부가적인 테마 -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap-theme.min.css">

	<!-- 합쳐지고 최소화된 최신 자바스크립트 -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js"></script>
	
	<!-- ajax 불러오기 -->
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>



<!DOCTYPE html>
<html lang="ko">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">

</head>

<body>

<br>
<br>
<center>

<div class="col">

		
			<?php


					$dir = $_COOKIE['filepath'];
					$filebin= 0;
					if(is_dir($dir)){
						if($dh = opendir($dir)){
						while(($file= readdir($dh)) !== false){
							
					 	$ext = array_pop(explode(".", strtolower($file)));
						 	if($ext != null){
						 		$filebin =1;
						 		//절대경로->상대경로 문자열 자름
						 		$dir2= substr($dir, 13, -1)."/";

						 		//경로 + 파일명 결합
						 		$path = $dir2.$file;
						 		
						 		
						 		echo "<div class='col-sm-6 col-md-3'>";
						 		echo "<div class='thumbnail'>";
								echo "<img src='$path' style='width:300px; height:200px;'>";
								echo "<div class='caption'>";
								echo "<h3>$file</h3>";
								
								echo "<p><a href='$path' download='$file' class='btn btn-primary'>다운로드</a></p>";
								echo "</div>";
								echo "</div>";
								echo "</div>";

							}
						}

						closedir($dh);						
						}
					}
					if($filebin ==0){
						echo "<span style='font-size:100px;color:white; background-color:#429F6B;padding-top:100px; padding-bottom:30px; padding-right:10px; padding-left:10px;'>EMPTY PCAP</span>";
				

					}						
					

			?>
</div>
</center>

</body>
</html>
