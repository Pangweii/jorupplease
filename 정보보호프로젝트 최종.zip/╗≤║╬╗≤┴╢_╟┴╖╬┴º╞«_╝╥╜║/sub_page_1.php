<?php
include 'db_login.php';
include 'page.php';
$conn = mysqli_connect($host, $id, $pw, $dbname);
if (mysqli_connect_errno()) {
    die('Connect Error: '.mysqli_connect_error());
}
  
?>

<!DOCTYPE html>
<html lang="ko">

<head>
<link rel="shortcut icon" href="image/Favicon.gif"> 
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<!-- 합쳐지고 최소화된 최신 CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">

	<!-- 부가적인 테마 -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap-theme.min.css">

	<!-- 합쳐지고 최소화된 최신 자바스크립트 -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js"></script>
	
	<!-- ajax 불러오기 -->
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>




	<style type="text/css">
		* { font-family: NanumGothic, 'Malgun Gothic'; }

	</style>

	<title> Packet Analysis & Restore For Network Forensics</title>
</head>

<Body>

<div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
  <div class="container">
    <div class="navbar-header">
   
      <a class="navbar-brand" href="#">Project by 相扶相助 </a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a href="./main_page.php">홈</a></li>
        <li><a href="./sub_page_1.php">상세정보</a></li>
        <li><a href="./sub_page_2.html">복원</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="./index.php" alt="재업로드"><span class="glyphicon glyphicon-transfer" ></span></a></li>

        </ul>
   
      </div>
  </div>
</div>
 <div class="jumbotron" style="background-color:white;">
        <table class = "table table-striped table-bordered table-hover">
    <thead>
    <center>
      <tr>
        <th style="text-align:center;">#</th>
        <th style="text-align:center;">date</th>
        <th style="text-align:center;">Source IP</th>
        <th style="text-align:center;">Source Port</th>
        <th style="text-align:center;">Destination IP</th>
        <th style="text-align:center;">Destination Port</th>
        <th style="text-align:center;">Protocol</th>
        <th style="text-align:center;">Length</th>
        <th style="text-align:center;">Service</th>
      </tr>
    </center>
    </thead>
    <tbody>

<?php
try{
  $page = $_GET['page'];
  
  $userid = $_COOKIE['userid'];


  $q = "select * from flow WHERE id='$userid'";
  $result = $conn->query($q);
  $total = $result->num_rows;

   if(!$page){ $page = 1;}
   
    // 한 페이지에 출력될 행 수 page_row, 전체페이지 total_page 
    $page_row = 100;
    $current_page = intval($page);  
    $total_page = ceil($total/$page_row);
   
    // SQL 쿼리 시 시작하는 행 start_row 구하기
    if ($current_page == 1) { $start_row = 0; } 
    else { $start_row = ($current_page * $page_row) - $page_row; } 
   
    // SQL 쿼리 시 끝나는 행 end_row 구하기
    $limit = $start_row + $page_row;
    if ($limit >= $total) 
    $limit = $total;
    $end_row = $limit - $start_row;             


    
  $check_val = "SELECT protocol AS pro, count FROM protocol WHERE id ='$userid' GROUP BY protocol ORDER BY count DESC";
 
  $first_qry = $conn->query($check_val);

  $first_qry2 = mysqli_fetch_array($first_qry);

 
  $query = "SELECT sq_number, date, srcIP, srcPT, dstIP, dstPT, protocol, len, service FROM flow A1 LEFT JOIN service_name B1 ON A1.dstPT=B1.port OR A1.srcPT=B1.port WHERE id='$userid' LIMIT $start_row, $end_row";    
  
  $result = $conn->query($query);
 
  while( $row = mysqli_fetch_array($result)){

    if($row["protocol"] == $first_qry2["pro"]){
      echo '<tr class="danger">';
    }else{
      echo '<tr>';
      }
      echo '<td style="text-align:center;">'.$row["sq_number"].'</td>';
      echo '<td style="text-align:center;">'.$row["date"].'</td>';
      echo '<td style="text-align:center;">'.$row["srcIP"].'</td>';
      echo '<td style="text-align:center;">'.$row["srcPT"].'</td>';
      echo '<td style="text-align:center;">'.$row["dstIP"].'</td>';
      echo '<td style="text-align:center;">'.$row["dstPT"].'</td>';
      echo '<td style="text-align:center;">'.$row["protocol"].'</td>';
      echo '<td style="text-align:center;">'.$row["len"].'</td>';
      echo '<td>'.$row["service"].'</td>';
      echo '</tr>';
   
 
    
  }

}catch(PDOException $e){
  $message = '<script>alert($e->getMessage())</script>';
}
?>
    </tbody>
  </table>
    </div>
      <center>
 <?php
  // 페이징 기능 추가
  $url = "sub_page_1.php?";
  page_nav($total_page, $current_page, $url); 
?>
</center>
  </div>

  <hr>
  <footer>
    <p>&copy; 상부상조 2016</p>
  </footer>
</div>
 
</body>

<?php mysql_close($conn);?>
</html>



