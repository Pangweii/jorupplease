<?php
include 'db_login.php';
include 'page.php';
$conn = mysqli_connect($host, $id, $pw, $dbname);
if (mysqli_connect_errno()) {
    die('Connect Error: '.mysqli_connect_error());
}
?>
<html>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript" src="https://www.google.com/jsapi"></script>
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">

  <!-- 부가적인 테마 -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap-theme.min.css">

  <!-- 합쳐지고 최소화된 최신 자바스크립트 -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js"></script>
  
  <!-- ajax 불러오기 -->
  <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<head>
</head>
<body>
<table class = "table table-striped table-bordered table-hover">
    <thead>
    <center>
      <tr>
        <th style="text-align:center;">#</th>
        <th style="text-align:center;">date</th>
        <th style="text-align:center;">Source IP</th>
        <th style="text-align:center;">Source Port</th>
        <th style="text-align:center;">Destination IP</th>
        <th style="text-align:center;">Destination Port</th>
        <th style="text-align:center;">Protocol</th>
        <th style="text-align:center;">Length</th>
        <th style="text-align:center;">Service</th>
      </tr>
    </center>
    </thead>
    <tbody>
<?php

                $page = $_GET['page'];
                $userid = $_COOKIE['userid'];
                  
                $search_pro = $_GET['value'];
                try{    

                   $q = "select * from flow WHERE id='$userid' AND protocol = '$search_pro'";
                  $result = $conn->query($q);
                  $total = $result->num_rows;

                   if(!$page){ $page = 1;}
                   
                    // 한 페이지에 출력될 행 수 page_row, 전체페이지 total_page 
                    $page_row = 100;
                    $current_page = intval($page);  
                    $total_page = ceil($total/$page_row);
                   
                    // SQL 쿼리 시 시작하는 행 start_row 구하기
                    if ($current_page == 1) { $start_row = 0; } 
                    else { $start_row = ($current_page * $page_row) - $page_row; } 
                   
                    // SQL 쿼리 시 끝나는 행 end_row 구하기
                    $limit = $start_row + $page_row;
                    if ($limit >= $total) 
                    $limit = $total;
                    $end_row = $limit - $start_row;             

              
                  $query = "SELECT sq_number, date, srcIP, srcPT, dstIP, dstPT, protocol, len, service FROM flow A1 LEFT JOIN service_name B1 ON A1.dstPT=B1.port OR A1.srcPT=B1.port WHERE id='$userid' AND protocol ='$search_pro' LIMIT $start_row, $end_row";    
                  
                  $result = $conn->query($query);
                 
                  while( $row = mysqli_fetch_array($result)){

                    
                      echo '<tr>';
                     
                      echo '<td style="text-align:center;">'.$row["sq_number"].'</td>';
                      echo '<td style="text-align:center;">'.$row["date"].'</td>';
                      echo '<td style="text-align:center;">'.$row["srcIP"].'</td>';
                      echo '<td style="text-align:center;">'.$row["srcPT"].'</td>';
                      echo '<td style="text-align:center;">'.$row["dstIP"].'</td>';
                      echo '<td style="text-align:center;">'.$row["dstPT"].'</td>';
                      echo '<td style="text-align:center;">'.$row["protocol"].'</td>';
                      echo '<td style="text-align:center;">'.$row["len"].'</td>';
                      echo '<td >'.$row["service"].'</td>';
                      echo '</tr>';
                
                    
                  }
                
             mysql_close($conn);
                }catch(PDOException $e){
                  $message = '<script>alert($e->getMessage())</script>';
                }
    ?>
    </tbody>
  </table>
    <Center>
   <?php
  // 페이징 기능 추가
  $url = "sub_popup2.php?value=".$search_pro."&";
  page_nav($total_page, $current_page, $url); 
?>
</Center>
</body>

</html>