<?php
include 'db_login.php';
$conn = mysqli_connect($host, $id, $pw, $dbname);
if (mysqli_connect_errno()) {
    die('Connect Error: '.mysqli_connect_error());
}

?>
  <meta charset="UTF-8">
<html>
  <head>
    <style>
    div{
      margin:0;
      padding:0;
     
    }
   </style>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = new google.visualization.arrayToDataTable([
          <?php
                echo '["Date","Traffic"],';

                $userid = $_COOKIE['userid'];
                          
                try{    
                  $query = "SELECT date, traffic FROM timeline WHERE id='$userid'";    
                  
                  $result = $conn->query($query);
          
                  while( $row = mysqli_fetch_array($result)){
                 
                      echo '["'.$row["date"].'",'.$row["traffic"].'],';
               
                  }
                
                  mysql_close($conn);
                }catch(PDOException $e){
                  $message = '<script>alert($e->getMessage())</script>';
                }
            ?>
          ],false);

      var chart = new google.visualization.AreaChart(document.getElementById('chart_div'));

        var options = {
          title: '시간별 트래픽량',
          hAxis: {title: 'Time',  titleTextStyle: {color: '#DCDCDC'}},
          vAxis: {minValue: 0},
          colors:['#006400','#429F6B'],
          
          backgroundColor:'#eee'
        };

          function myClickHandler(){
               slc_data = data.getValue(chart.getSelection()[0].row, 0);
                var m_path = "./sub_popup_time.php?value="+slc_data;
                window.open(m_path,"sub","width=900, height=400, toolbar=no, location=no,status=no, menubar=no, scrollbars=no, resizable=no, left=300, top=200, return false;");
                
              
            }

            google.visualization.events.addListener(chart, 'select', myClickHandler);

       
        chart.draw(data, options);
      }
    </script>
  </head>
  <body>
    <div id="chart_div" style="width: 100%; height: 280px;"></div>
  </body>
</html>