<meta charset="UTF-8">
<?php 
    include 'db_login.php';

    $conn = mysqli_connect($host, $id, $pw, $dbname);
    if (mysqli_connect_errno()) {
        die('Connect Error: '.mysqli_connect_error());
    }

      if(isset($_POST['submit'])){

    
        $checkfile=$_FILES["input-1a"]["name"];
        $checkMac = $_POST['mac'];
       
        $ext = array_pop(explode(".", strtolower($checkfile)));
      
      
          if(!in_array($ext, array('pcap'))){
          ?><script>alert("pcap 파일이 아닙니다.");
          
            history.go(-1);

            </script><?php
        }else{
        
        $upload_dir="/var/www/html/tmp/";
        

        if(is_uploaded_file($_FILES["input-1a"]["tmp_name"])){
         
       
          $dest = $upload_dir . $_FILES["input-1a"]["name"];

     
          if(move_uploaded_file($_FILES["input-1a"]["tmp_name"], $dest)){

          
            $jsonData=split(";",exec("python proc/main.py $dest $checkMac"));
             
             /* echo "그냥 jsonData : ". $jsonData. "<br>";
              echo "jsonData 배열 : ". $jsonData[0];

              if($jsonData < 0 ){                
                echo "<script>alert('pcap 파일이 아닙니다.');history.go(-1);</script>";
               }
    */

          
           
            setcookie('userid', $jsonData[0], time()+(60*60),'/');
            setcookie('filepath', $jsonData[6], time()+(60*60),'/');
 
            
            //timeline 입력
            $timeline = "INSERT INTO timeline VALUES".$jsonData[5];
            mysqli_query($conn, $timeline);

             //IO 입력
            $inout = "INSERT INTO IO VALUES".$jsonData[4];
            mysqli_query($conn, $inout);

             //geomap 입력
            $geomap  = "INSERT INTO geomap VALUES".$jsonData[3]; 
            mysqli_query($conn, $geomap);

           //프로토콜 입력
            $protocol = "INSERT INTO protocol VALUES".$jsonData[2];
            mysqli_query($conn, $protocol);

            //flow 입력
			$flow_qry=split("@",$jsonData[1]);
			$i=0;
			while($i<count($flow_qry))
			{
				$flow = "INSERT INTO flow VALUES".$flow_qry[$i];
				mysqli_query($conn, $flow);
				$i++;
			}           
            //echo "******타임라인값*******<br>".$timeline."<br>";
            //echo "******인아웃값*******<br>".$inout."<br>";
            //echo "******지오맵값*******<br>".$geomap."<br>";
            //echo "******프로토콜값*******<br>".$protocol."<br>";
            //echo "******flow값*******<br>".$flow."<br>";
           
           
            ?><script>document.location.href='main_page.php';</script><?php
            
            }
          else die("error-2");
        }
      }
    }
      mysql_close($conn);
?>

